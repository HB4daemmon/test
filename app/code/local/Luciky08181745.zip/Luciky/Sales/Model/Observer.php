<?php
/**
 * 
 */

class Luciky_Sales_Model_Observer extends Mage_Sales_Model_Observer{

	/**
	 * 
	 *quoteitem保存之后操作：
	 * @param Varien_Event_Observer $observer
	 */
	
	public function CheckoutAddAfter(Varien_Event_Observer $observer){
	
		$_quote=$observer->getQuote();
		$_group=$_quote->getStore()->getGroup();
		$store_groups=Mage::getModel('sales/quote_storegroup')->getCollection();
		$store_groups->addFieldtoFilter('quote_id',$_quote->getId())
				->addFieldtoFilter('storegroup_id',$_group->getId());
		if (count($store_groups) == 0 ){
		
				$store_group = Mage::getModel('sales/quote_storegroup');
				$store_group->setQuote($_quote)
							->setStoregroupId($_group->getId())
							->setStoregroupName($_group->getName());
				try {
					$store_group->save();
				} catch (Exception $e) {
					Mage::log('store_group cannot be inserted ');
				}
		}
//		$item = $observer->getQuoteItem();
//		$_quote=$item->getQuote();
//		$_store=$item->getStore();
//		$_storegroupid=$item->getStore()->getGroupId();
////		Mage::log($_quote->getId().'---'.$_store->getId().'---'.$_storegroupid);
////		
//		$store_groups=Mage::getModel('sales/quote_storegroup')->getCollection();
//		$store_groups->addFieldtoFilter('quote_id',$_quote->getId())
//					->addFieldtoFilter('storegroup_id',$_storegroupid);
//				
//		if (count($store_groups) > 0){//存在storegroups
//			$store_group=$store_groups->getFirstItem();
//		}else{//如果不存在就创建一个
//		$store_group=Mage::getModel('sales/quote_storegroup');
//		$store_group->setQuote($item->getQuote())
//					-> setStoregroupfromStore($item->getStore())
//					->save();
//		}
//		
//		Mage::log($store_group->getId());
	//	$item->setStoregroupId($store_group->getId())->save();

		
	}
	/**
	 * 
	 * 拆分订单
	 * @param Varien_Event_Observer $observer
	 */
	public function SaveOrdertoOrders(Varien_Event_Observer $observer){
	
		$order=$observer->getOrderIds();
		$str = var_export($order,true);
		Mage::log($str);
		
	}


}